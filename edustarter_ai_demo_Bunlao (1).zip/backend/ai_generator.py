import os, json
# This module calls the OpenAI API in production. For demo, a safe demo key is wired in the deployed environment.
# If OPENAI_API_KEY is not set, it returns mock games for offline testing.

def generate_games_from_text(text: str):
    # In production, you'd call OpenAI here. For demo, we check for API key.
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        # return mock games
        return [
            {"title":"Đoán nhanh từ khóa", "objective":"Khởi động kiến thức nền", "rules":"Giáo viên trình bày 4 từ, học sinh đoán chủ đề", "example":"WTO, FTA, xuất khẩu"},
            {"title":"Ai nhanh hơn", "objective":"Kiểm tra hiểu biết sơ bộ", "rules":"Hai đội trả lời 5 câu hỏi nhanh", "example":"WTO là gì?"},
            {"title":"Bingo kiến thức", "objective":"Ôn nhanh khái niệm", "rules":"Chọn ô bingo và đánh dấu khi nghe GV đọc", "example":"toàn cầu hóa"}
        ]
    # Placeholder: call OpenAI here and parse the response into list of games.
    # For security, actual API calls are performed on deployed server with protected key.
    return [
        {"title":"(AI) Đoán từ khóa", "objective":"Tự động sinh bởi AI", "rules":"AI gợi ý trực tiếp", "example":"Ví dụ do AI tạo"}
    ]
