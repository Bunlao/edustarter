from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import os, tempfile, json
from utils.docx_reader import extract_text_from_docx
from utils.pdf_reader import extract_text_from_pdf
from ai_generator import generate_games_from_text

app = FastAPI(title="EduStarter Demo API")

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    filename = file.filename.lower()
    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        tmp.write(await file.read())
        tmp_path = tmp.name

    if filename.endswith(".docx"):
        text = extract_text_from_docx(tmp_path)
    elif filename.endswith(".pdf"):
        text = extract_text_from_pdf(tmp_path)
    else:
        raise HTTPException(status_code=400, detail="Unsupported file type")
    os.remove(tmp_path)
    games = generate_games_from_text(text)
    return {"content": text[:3000], "games": games}

@app.post("/generate")
async def generate_from_text(payload: dict):
    text = payload.get("text") or payload.get("topic", "")
    if not text:
        raise HTTPException(status_code=400, detail="Provide 'text' or 'topic' in payload")
    games = generate_games_from_text(text)
    return {"games": games}

@app.get("/health")
def health():
    return {"status":"ok"}
