# EduStarter AI Demo (VN) - Repository for Bunlao

This repo is prepared for quick deployment to Render.com. It contains a minimal demo:
- Backend: FastAPI that accepts uploads (.docx/.pdf) and generates warm-up games (via AI or mock)
- Frontend: Static single-file page with a Swiper carousel to show generated games
- Dockerfile + render.yaml for automatic Render deployment

## How to deploy (one-click on Render)
1. Create a new GitHub repository named **edustarter-ai-demo** under your account **Bunlao**.
2. Upload all files from this repo to the GitHub repository (make it Public).
3. Go to https://render.com and connect your GitHub account.
4. Create a new Web Service and select this repo. Render will read `render.yaml` and build the Docker image.
5. After deploy completes, open the service URL (e.g. https://edustarter-ai-demo.onrender.com).
6. Use the web UI to upload .docx/.pdf or enter a topic and Generate games.

## Notes
- In this demo, the backend returns mock games if no OPENAI_API_KEY is configured. When deploying, to enable real AI generation, set an environment variable `OPENAI_API_KEY` in Render secrets.
- The frontend is a static HTML file placed at `/frontend/index.html`. The container serves endpoints under the same origin.
- For production use, you should separate frontend static hosting and backend API and secure the API key properly.

---
Prepared for GitHub user: Bunlao
