# EduStarter - Deploy-ready Demo (FastAPI)

This package is prepared for quick deployment to Render.com.

## Contents
- `main.py` - FastAPI app that serves a simple UI and handles .docx/.pdf uploads.
- `templates/index.html` - Simple frontend served by FastAPI (no separate React build required).
- `requirements.txt` - Python dependencies.
- `Dockerfile` - Deploy-ready Dockerfile.
- `render.yaml` - Render blueprint for auto-deploy.

## How to deploy (GitHub + Render)
1. Create a new GitHub repository (public) under your account (e.g. `edustarter`).
2. Upload all files and folders from this package at the repository root.
3. Go to https://render.com and create a new Web Service -> Connect to GitHub repository.
4. Render will detect `render.yaml` and `Dockerfile` and build your service automatically.
5. After build, open the public URL Render provides; the app serves a UI at `/`.

## Notes
- The app listens on the port defined by the `PORT` environment variable; default 5000.
- This demo includes server-side file parsing for `.docx` and `.pdf` and returns simple mock game suggestions.
- To enable real AI integration (OpenAI), add your code and set `OPENAI_API_KEY` as an environment variable in Render service settings.
