import os
from fastapi import FastAPI, UploadFile, File, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import tempfile
from pathlib import Path

def extract_text_from_docx(path):
    from docx import Document
    doc = Document(path)
    return "\n".join([p.text for p in doc.paragraphs if p.text and p.text.strip()])

def extract_text_from_pdf(path):
    from PyPDF2 import PdfReader
    reader = PdfReader(path)
    text = ""
    for p in reader.pages:
        t = p.extract_text()
        if t:
            text += t + "\n"
    return text

app = FastAPI(title="EduStarter Deploy-Ready Demo")

base_dir = Path(__file__).parent
templates = Jinja2Templates(directory=str(base_dir / "templates"))
app.mount("/static", StaticFiles(directory=str(base_dir / "static")), name="static")

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    filename = file.filename.lower()
    suffix = Path(filename).suffix
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(await file.read())
        tmp_path = tmp.name
    try:
        if suffix == ".docx":
            text = extract_text_from_docx(tmp_path)
        elif suffix == ".pdf":
            text = extract_text_from_pdf(tmp_path)
        else:
            return JSONResponse({"error":"Unsupported file type. Upload .docx or .pdf"}, status_code=400)
    finally:
        try:
            os.remove(tmp_path)
        except Exception:
            pass
    snippet = text[:200].replace("\n", " ")
    games = [
        {"title":"Đoán nhanh từ khóa", "objective":"Khởi động kiến thức nền", "rules":"Giáo viên trình bày 4 từ khóa, học sinh đoán chủ đề", "example": snippet},
        {"title":"Ai nhanh hơn", "objective":"Kiểm tra hiểu biết sơ bộ", "rules":"Hai đội trả lời 5 câu hỏi nhanh", "example": snippet},
        {"title":"Bingo kiến thức", "objective":"Ôn nhanh khái niệm", "rules":"Chọn ô bingo và đánh dấu khi nghe GV đọc", "example": snippet},
    ]
    return {"content": text, "games": games}

@app.post("/generate")
async def generate_from_text(text: str = Form(...)):
    snippet = text[:200].replace("\n", " ")
    games = [
        {"title":"Đoán nhanh từ khóa", "objective":"Khởi động kiến thức nền", "rules":"Giáo viên trình bày 4 từ khóa, học sinh đoán chủ đề", "example": snippet},
        {"title":"Ai nhanh hơn", "objective":"Kiểm tra hiểu biết sơ bộ", "rules":"Hai đội trả lời 5 câu hỏi nhanh", "example": snippet},
        {"title":"Bingo kiến thức", "objective":"Ôn nhanh khái niệm", "rules":"Chọn ô bingo và đánh dấu khi nghe GV đọc", "example": snippet},
    ]
    return {"games": games}

@app.get("/health")
def health():
    return {"status":"ok"}

if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 5000))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)
