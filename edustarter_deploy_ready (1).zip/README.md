# EduStarter - Deploy Ready (FastAPI)

This package is a deploy-ready template for Render.com.
It includes a FastAPI backend that serves a simple integrated UI,
supports uploading .docx and .pdf files, extracts text, and generates mock/AI games.

## Deploy steps
1. Unzip and push all files to a public GitHub repository (e.g. edustarter-ai-demo).
2. Go to https://render.com, connect GitHub, and create a new Web Service. Render will use render.yaml.
3. After deploy, open the public URL. Enter a topic or upload a .docx/.pdf to see suggested games.
4. To enable real AI generation, set OPENAI_API_KEY in Render environment variables.