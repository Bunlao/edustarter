import os
def generate_games_from_text(text: str):
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key or not text or len(text.strip())==0:
        return [
            {"title":"Đoán nhanh từ khóa", "objective":"Khởi động kiến thức nền", "rules":"GV đưa 4 từ khóa, HS đoán chủ đề", "example":"WTO, FTA, xuất khẩu"},
            {"title":"Ai nhanh hơn", "objective":"Kiểm tra hiểu biết sơ bộ", "rules":"Hai đội trả lời 5 câu hỏi nhanh", "example":"WTO là gì?"},
            {"title":"Bingo kiến thức", "objective":"Ôn nhanh khái niệm", "rules":"Chọn ô bingo và gạch khi nghe GV đọc", "example":"toàn cầu hóa"}
        ]
    return [
        {"title":"(AI) Đoán từ khóa", "objective":"Được sinh bởi AI", "rules":"AI phân tích và gợi ý", "example":"Ví dụ sinh bởi AI"}
    ]
