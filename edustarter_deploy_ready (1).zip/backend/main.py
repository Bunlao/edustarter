from fastapi import FastAPI, File, UploadFile, Form, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import tempfile, os
from utils.docx_reader import extract_text_from_docx
from utils.pdf_reader import extract_text_from_pdf
from ai_generator import generate_games_from_text

app = FastAPI(title="EduStarter Demo - Deploy Ready")

templates = Jinja2Templates(directory="backend/templates")

app.mount("/static", StaticFiles(directory="backend/static"), name="static")

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "games": [], "filename": ""})

@app.post("/upload", response_class=HTMLResponse)
async def upload_file(request: Request, file: UploadFile = File(...)):
    filename = file.filename
    ext = os.path.splitext(filename)[1].lower()
    with tempfile.NamedTemporaryFile(delete=False, suffix=ext) as tmp:
        tmp.write(await file.read())
        tmp_path = tmp.name

    try:
        if ext == ".docx":
            text = extract_text_from_docx(tmp_path)
        elif ext == ".pdf":
            text = extract_text_from_pdf(tmp_path)
        else:
            text = ""
    finally:
        try:
            os.remove(tmp_path)
        except Exception:
            pass

    games = generate_games_from_text(text)
    return templates.TemplateResponse("index.html", {"request": request, "games": games, "filename": filename})

@app.post("/generate", response_class=HTMLResponse)
async def generate_from_text(request: Request, topic: str = Form(...)):
    games = generate_games_from_text(topic)
    return templates.TemplateResponse("index.html", {"request": request, "games": games, "filename": ""})

@app.get("/health")
def health():
    return {"status": "ok"}
